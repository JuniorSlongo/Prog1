
package br.com.sistemaif.view;

import br.com.sistemaif.model.dao.ProdutoDAO;
import br.com.sistemaif.model.vo.Produto;


public class TestaProduto {
    public static void main(String[] args){
        
        
        ProdutoDAO produtoDAO = new ProdutoDAO();
        
        
        ProdutoDAO produtoDAO = new ProdutoDAO();
        Produto.setNome("Pirulito");
        Produto.setValor(8.5);
        Produto.setFrete(1);
        
        produtoDAO.CadastrarProduto(produto);
    }
}
