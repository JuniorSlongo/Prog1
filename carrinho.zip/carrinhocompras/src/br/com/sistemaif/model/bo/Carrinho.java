package br.com.sistemaif.model.bo;

import br.com.sistemaif.model.vo.Item;
import br.com.sistemaif.model.vo.Produto;
import java.util.ArrayList;

public class Carrinho {
    
    private ArrayList<Item> itensCompra;

    public Carrinho() {
        this.itensCompra = new ArrayList<>();
    }
    
    public void adicionarItem(Produto produto, int quantidade, boolean garantia){
        Item item = new Item(produto, quantidade, garantia);
        this.itensCompra.add(item);        
    }

    public ArrayList<Item> getItensCompra() {
        return itensCompra;
    }
    
    public void removerItem(Item item){
        this.itensCompra.remove(item);
    }
    
    public void removerItem(int i){
        this.itensCompra.remove(i);
    }
        
    public void alterarQuantidade(int i, int quantidade){
        Item item = this.itensCompra.get(i);
        item.setQuantidade(quantidade);        
    }
    
    public double totalizarCompra(){
        double total = 0;
        for (Item item : itensCompra) {
            double parcial = item.getProduto().getValor() * item.getQuantidade() + item.getProduto().getFrete();
            total += parcial;
        }
        
        return total;
    }
    
}